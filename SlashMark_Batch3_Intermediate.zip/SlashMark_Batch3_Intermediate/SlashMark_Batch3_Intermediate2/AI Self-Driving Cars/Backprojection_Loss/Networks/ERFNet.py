# ERFNet full model definition for Pytorch
# Sept 2017
# Eduardo Romera
#######################

import torch
import torch.nn as nn
import torch.nn.init as init
import torch.nn.functional as F

class DownsamplerBlock (nn.Module):
    def __init__(self, ninput, noutput):
        super().__init__()

        self.conv = nn.Conv2d(ninput, noutput-ninput, (3, 3), stride=2, padding=1, bias=True)
        self.pool = nn.MaxPool2d(2, stride=2)
        self.bn = nn.BatchNorm2d(noutput, eps=1e-3)

    def forward(self, input):
        output = torch.cat([self.conv(input), self.pool(input)], 1)
        output = self.bn(output)
        return F.relu(output)
    

class non_bottleneck_1d (nn.Module):
    def __init__(self, chann, dropprob, dilated):        
        super().__init__()

        self.conv3x1_1 = nn.Conv2d(chann, chann, (3, 1), stride=1, padding=(1,0), bias=True)

        self.conv1x3_1 = nn.Conv2d(chann, chann, (1,3), stride=1, padding=(0,1), bias=True)

        self.bn1 = nn.BatchNorm2d(chann, eps=1e-03)

        self.conv3x1_2 = nn.Conv2d(chann, chann, (3, 1), stride=1, padding=(1*dilated,0), bias=True, dilation = (dilated,1))

        self.conv1x3_2 = nn.Conv2d(chann, chann, (1,3), stride=1, padding=(0,1*dilated), bias=True, dilation = (1, dilated))

        self.bn2 = nn.BatchNorm2d(chann, eps=1e-03)

        self.dropout = nn.Dropout2d(dropprob)
        

    def forward(self, input):

        output = self.conv3x1_1(input)
        output = F.relu(output)
        output = self.conv1x3_1(output)
        output = self.bn1(output)
        output = F.relu(output)

        output = self.conv3x1_2(output)
        output = F.relu(output)
        output = self.conv1x3_2(output)
        output = self.bn2(output)

        if (self.dropout.p != 0):
            output = self.dropout(output)
        
        return F.relu(output+input)    #+input = identity (residual connection)


class Encoder(nn.Module):
    def __init__(self, in_channels, num_classes):
        super().__init__()
        self.initial_block = DownsamplerBlock(in_channels, 16)

        self.layers = nn.ModuleList()

        self.layers.append(DownsamplerBlock(16,64))

        for x in range(0, 5):    #5 times
           self.layers.append(non_bottleneck_1d(64, 0.03, 1)) 

        self.layers.append(DownsamplerBlock(64,128))

        for x in range(0, 2):    #2 times
            self.layers.append(non_bottleneck_1d(128, 0.3, 2))
            self.layers.append(non_bottleneck_1d(128, 0.3, 4))
            self.layers.append(non_bottleneck_1d(128, 0.3, 8))
            self.layers.append(non_bottleneck_1d(128, 0.3, 16))

        #Only in encoder mode:
        self.output_conv = nn.Conv2d(128, num_classes, 1, stride=1, padding=0, bias=True)

    def forward(self, input, predict=False):
        output = self.initial_block(input)

        for layer in self.layers:
            output = layer(output)

        if predict:
            output = self.output_conv(output)

        return output


class UpsamplerBlock (nn.Module):
    def __init__(self, ninput, noutput):
        super().__init__()
        self.conv = nn.ConvTranspose2d(ninput, noutput, 3, stride=2, padding=1, output_padding=1, bias=True)
        self.bn = nn.BatchNorm2d(noutput, eps=1e-3)

    def forward(self, input):
        output = self.conv(input)
        output = self.bn(output)
        return F.relu(output)

class Decoder (nn.Module):
    def __init__(self, num_classes, pretrain, do_segmentation=False):
        super().__init__()
        self.pretrain = pretrain

        self.layers = nn.ModuleList()

        self.layers.append(UpsamplerBlock(128,64))
        self.layers.append(non_bottleneck_1d(64, 0, 1))
        self.layers.append(non_bottleneck_1d(64, 0, 1))

        self.layers.append(UpsamplerBlock(64,16))
        self.layers.append(non_bottleneck_1d(16, 0, 1))
        self.layers.append(non_bottleneck_1d(16, 0, 1))

        self.output_conv = nn.ConvTranspose2d( 16, num_classes, 2, stride=2, padding=0, output_padding=0, bias=True)
        if pretrain:
            self.output_conv2 = nn.ConvTranspose2d( 16, num_classes + 1 , 2, stride=2, padding=0, output_padding=0, bias=True)


        self.do_segmentation = do_segmentation
        if do_segmentation: 
            self.layers1 = nn.ModuleList()
            self.layers1.append(UpsamplerBlock(128,64))
            self.layers1.append(non_bottleneck_1d(64, 0, 1))
            self.layers1.append(non_bottleneck_1d(64, 0, 1))

            self.layers1.append(UpsamplerBlock(64,16))
            self.layers1.append(non_bottleneck_1d(16, 0, 1))
            self.layers1.append(non_bottleneck_1d(16, 0, 1))
            output_conv3 = nn.ConvTranspose2d(16, num_classes + 1 , 2, stride=2, padding=0, output_padding=0, bias=True)
            self.layers1.append(output_conv3)


    def forward(self, input, flag):
        output = input
        output_seg = input

        for layer in self.layers:
            output = layer(output)
        if self.pretrain:

            if flag:
                output = self.output_conv(output)
            else:
                output = self.output_conv2(output)
        else:
            output = self.output_conv(output)

        if self.do_segmentation:
            for layer1 in self.layers1:
                output_seg = layer1(output_seg)
        return output, output_seg

# ERFNet
class Net(nn.Module):
    def __init__(self, layers=18, in_channels=1, out_channels=1, pretrained=False, pool=False):  #use encoder to pass pretrained encoder
        super().__init__()
        self.encoder = Encoder(in_channels, out_channels)
        self.decoder = Decoder(out_channels, pretrained)
        
    def forward(self, input, flag, only_encode=False):
        if only_encode:
            return self.encoder.forward(input, predict=True)
        else:
            encoder_output = self.encoder(input)
            decoder_output, output_seg = self.decoder.forward(encoder_output, flag)
            return encoder_output, decoder_output, output_seg
